import "./style.css";

export { Login } from "./Login";
export { Register } from "./register";