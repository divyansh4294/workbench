from flask import Blueprint, Flask
from flask.globals import request
import pandas as pd
from flask import jsonify
from UploadDataset import df_to_json;
from UploadDataset import df_datatype;
from UploadDataset import df_null;


tableFunction_api = Blueprint('tableFunction_api', __name__)

@tableFunction_api.route('/table', methods=['GET', 'POST', 'DELETE'])
def tableFunction():
    if request.method == 'POST':
        print("Post is running")
        data = request.get_json("data")
        dropColumn = data.get("dropcolumn")
        # print("dropColumn:",dropColumn)
        rows = data.get("rows")
        cols = data.get("cols")
        collist = []
        # print("Post1 is running")
        for i in cols:
            collist.append(i.get("name"))
            print(i)
        df = pd.DataFrame(rows, columns=collist)
        # print("Post2 is running")

        df = df.drop(dropColumn, axis=1)
        # print("Post3 is running")

        # print("df1:",df)
        dflist, dfdict = df_to_json(df)
        dtype = df_datatype(df)
        dfNull = df_null(df)
        # print("Post4 is running")

        # print("data:",dflist, dfdict, dtype, dfNull)
        return jsonify({
            "Rows": dflist,
            "Columns": dfdict,
            "Nulls": dfNull,
            "Dtypes": dtype,
        })

    elif request.method == 'GET':
        return {"r":0}
    elif request.method == 'DELETE':
        return 0